import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Conversation } from './entities/conversation.entity';
import { ChatController } from './controllers/chat.controller';
import { ChatService } from './services/chat.service';
import { OpenAIService } from './services/openai.service';

@Module({ // Decorador que transforma a classe em um módulo NestJS
  imports: [TypeOrmModule.forFeature([Conversation])], // Disponibiliza a entidade Conversation para uso com TypeORM dentro do módulo
  controllers: [ChatController], // Registra o controller que expõe as rotas HTTP do chat
  providers: [ChatService, OpenAIService], // Registra os serviços (injeção de dependência) que serão usados no módulo
})
export class ChatModule {}