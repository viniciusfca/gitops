import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

export enum MessageRole { // Enum que define os possíveis papéis de uma mensagem
  USER = 'user', // Papel do usuário
  ASSISTANT = 'assistant', // Papel do assistente (IA)
}

export interface Message { // Interface que descreve o formato de uma mensagem dentro da conversa
  id: string; // Identificador único da mensagem
  role: MessageRole; // Papel de quem enviou a mensagem (user ou assistant)
  content: string; // Texto da mensagem
  timestamp: Date; // Data/hora em que a mensagem foi criada
}

@Entity('conversations') // Define que a classe será mapeada como a tabela "conversations" no banco
export class Conversation {
  @PrimaryGeneratedColumn('uuid') // Cria a coluna "id" como chave primária gerada automaticamente em formato UUID
  id: string;

  @Column('jsonb') // Coluna que armazena as mensagens no formato JSON binário (ótimo para Postgres)
  messages: Message[]; // Array de mensagens, segue a estrutura da interface Message

  @Column({ default: false }) // Coluna booleana que indica se a conversa foi finalizada, começa como "false"
  isFinished: boolean;

  @CreateDateColumn() // Coluna que salva automaticamente a data/hora em que a conversa foi criada
  startedAt: Date;

  @Column({ nullable: true }) // Coluna opcional (pode ser nula) para armazenar quando a conversa foi finalizada
  finishedAt: Date;

  @UpdateDateColumn() // Coluna que atualiza automaticamente a cada modificação da linha
  updatedAt: Date;
}
