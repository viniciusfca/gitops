import { Injectable } from '@nestjs/common';
import OpenAI from 'openai';
import { ConfigService } from '@nestjs/config';

@Injectable() // Torna a classe injetável pelo NestJS (Dependency Injection)
export class OpenAIService { // Serviço que encapsula a integração com a OpenAI
  private openai: OpenAI; // Instância/cliente do SDK da OpenAI

  constructor(private configService: ConfigService) { // Injeta o ConfigService para ler variáveis de ambiente/config
    this.openai = new OpenAI({ // Cria o cliente da OpenAI
      apiKey: this.configService.get<string>('OPENAI_API_KEY'), // Lê a API key "OPENAI_API_KEY" da config
    }); // Fim da criação do cliente
  } // Fim do construtor

  async getChatCompletion(messages: Array<{ role: string; content: string }>) { // Método assíncrono que recebe o histórico de mensagens
    try { // Início do tratamento de erros
      const completion = await this.openai.chat.completions.create({ // Chama a API de chat/completions da OpenAI
        model: 'gpt-3.5-turbo', // Define o modelo a ser usado
        messages: messages as any, // Passa o histórico no formato { role, content }
        max_tokens: 1000, // Limita o tamanho máximo da resposta gerada
        temperature: 0.7, // Controla criatividade/variação da resposta
      }); // Fim da chamada à API

      return completion.choices[0]?.message?.content || 'Desculpe, não consegui gerar uma resposta.'; // Retorna o texto da 1ª escolha ou um fallback
    } catch (error) { // Captura qualquer erro da chamada
      console.error('Erro ao chamar OpenAI:', error); // Loga o erro para depuração
      throw new Error('Erro interno do servidor ao processar mensagem'); // Propaga um erro genérico para a aplicação
    } // Fim do try/catch
  } // Fim do método getChatCompletion
} // Fim da classe OpenAIService
