# Recriando ChatGPT - Passo a Passo Completo

Este documento apresenta o passo a passo completo para criar um clone do ChatGPT usando NestJS, TypeORM, PostgreSQL e OpenAI API.

## 📚 Visão Geral da Arquitetura

### Stack Tecnológica Escolhida
- **NestJS**: Framework Node.js robusto com arquitetura modular
- **TypeORM**: ORM para TypeScript com suporte a migrations
- **PostgreSQL**: Banco relacional confiável para persistência
- **OpenAI API**: Integração com GPT para respostas inteligentes
- **Docker**: Containerização para ambiente consistente

### Arquitetura em Camadas
```
┌─────────────────┐
│   Controller    │ ← Recebe requisições HTTP
├─────────────────┤
│    Service      │ ← Lógica de negócio
├─────────────────┤
│   Repository    │ ← Acesso aos dados
├─────────────────┤
│   Database      │ ← PostgreSQL
└─────────────────┘
```

## 1. Criando o Projeto Base

### 1.1 Criar projeto NestJS
```bash
npm i -g @nestjs/cli
nest new recriando-chatgpt
cd recriando-chatgpt
```

### 1.2 Instalar dependências necessárias
```bash
npm install @nestjs/typeorm typeorm pg @nestjs/config
npm install class-validator class-transformer
npm install openai
npm install uuid @types/uuid
```

**📋 Detalhamento das Dependências:**
- `@nestjs/typeorm`: Integração do TypeORM com NestJS
- `typeorm`: ORM para mapeamento objeto-relacional
- `pg`: Driver PostgreSQL para Node.js
- `@nestjs/config`: Gerenciamento de variáveis de ambiente
- `class-validator`: Validação declarativa com decorators
- `class-transformer`: Transformação de objetos TypeScript
- `openai`: SDK oficial da OpenAI para Node.js
- `uuid`: Geração de identificadores únicos

### 1.3 Instalar dependências de desenvolvimento
```bash
npm install --save-dev @types/pg
```

**❓ Possíveis Questionamentos:**
- **P: Por que NestJS ao invés de Express puro?**
  - R: NestJS oferece arquitetura modular, injeção de dependências, decorators, e melhor organização para projetos médios/grandes
- **P: Por que PostgreSQL ao invés de MongoDB?**
  - R: Estrutura relacional garante consistência dos dados de conversas e mensagens
- **P: Por que TypeORM ao invés de Prisma?**
  - R: TypeORM tem melhor integração nativa com NestJS e suporte robusto a decorators

## 2. Configuração do Docker

### 2.1 Criar docker-compose.yml
```yaml
version: '3.8'

services:
  postgres:
    image: postgres:15-alpine
    container_name: chatgpt-clone-db
    environment:
      POSTGRES_DB: chatgpt_clone
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
    networks:
      - chatgpt-network

volumes:
  postgres_data:

networks:
  chatgpt-network:
    driver: bridge
```

### 2.2 Subir banco de dados
```bash
docker compose up -d
```

**📋 Responsabilidade do Docker:**
- **PostgreSQL**: Armazenamento persistente de conversas e mensagens
- **Redis**: Cache opcional para sessões (preparado para uso futuro)
- **Volumes**: Garantem persistência dos dados entre restarts

**❓ Possíveis Questionamentos:**
- **P: Por que usar Docker para desenvolvimento?**
  - R: Garante ambiente consistente, evita problemas de "funciona na minha máquina"
- **P: Por que Redis se não está sendo usado?**
  - R: Preparação para funcionalidades futuras como cache de sessões e rate limiting
- **P: Por que Alpine Linux nas imagens?**
  - R: Imagens menores, mais seguras e com menos superfície de ataque

## 3. Configuração de Variáveis de Ambiente

### 3.1 Criar arquivo .env
```env
# Database
DATABASE_HOST=localhost
DATABASE_PORT=5432
DATABASE_USERNAME=postgres
DATABASE_PASSWORD=postgres
DATABASE_NAME=chatgpt_clone

# OpenAI
OPENAI_API_KEY=sua_chave_openai_aqui

# Application
PORT=3000
```

### 3.2 Adicionar .env ao .gitignore
```gitignore
# Variáveis de ambiente
.env
.env.local
.env.production
```

**📋 Segurança das Variáveis:**
- **Nunca commitar** arquivos .env no repositório
- **Usar .env.example** para documentar variáveis necessárias
- **Rotacionar chaves** regularmente em produção

**❓ Possíveis Questionamentos:**
- **P: Como obter a chave da OpenAI?**
  - R: Criar conta em platform.openai.com, ir em API Keys e gerar nova chave
- **P: Qual modelo OpenAI usar?**
  - R: gpt-3.5-turbo é mais barato e rápido; gpt-4 é mais inteligente mas caro
- **P: Como gerenciar diferentes ambientes?**
  - R: Usar .env.development, .env.staging, .env.production

## 4. Criando as Entidades

### 4.1 Criar pasta entities
```bash
mkdir src/entities
```

### 4.2 Criar conversation.entity.ts
```typescript
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

export enum MessageRole {
  USER = 'user',
  ASSISTANT = 'assistant',
}

export interface Message {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: Date;
}

@Entity('conversations')
export class Conversation {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column('jsonb')
  messages: Message[];

  @Column({ default: false })
  isFinished: boolean;

  @CreateDateColumn()
  startedAt: Date;

  @Column({ nullable: true })
  finishedAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
```

**📋 Responsabilidade da Entidade Conversation:**
- **Agregação**: Agrupa mensagens relacionadas em uma conversa
- **Estado**: Controla se a conversa está ativa ou finalizada
- **Auditoria**: Timestamps automáticos para rastreabilidade
- **Flexibilidade**: JSONB permite estrutura flexível para mensagens

**📋 Design Decisions Explicadas:**
- **UUID como PK**: Identificadores únicos seguros e distribuídos
- **JSONB para mensagens**: Performance + flexibilidade para estruturas aninhadas
- **Enum MessageRole**: Type safety e consistência nos papéis
- **Interface Message**: Contrato claro para estrutura de mensagens

**❓ Possíveis Questionamentos:**
- **P: Por que JSONB ao invés de tabela separada para Message?**
  - R: Mensagens sempre são acessadas junto com a conversa; JSONB é mais performático para esse padrão
- **P: Por que não usar relacionamento 1:N tradicional?**
  - R: JSONB reduz JOINs, melhora performance de leitura, e mensagens não precisam ser consultadas independentemente
- **P: Como fazer busca nas mensagens com JSONB?**
  - R: PostgreSQL oferece operadores JSON poderosos e índices GIN para busca eficiente
- **P: Por que timestamps manuais nas mensagens?**
  - R: Controle fino sobre quando cada mensagem foi criada, independente do salvamento da conversa

## 5. Criando os DTOs

### 5.1 Criar pasta dto
```bash
mkdir src/dto
```

### 5.2 Criar chat.dto.ts
```typescript
import { IsString, IsNotEmpty, IsUUID, IsOptional } from 'class-validator';
import { Message } from '../entities/conversation.entity';

export class SendMessageDto {
  @IsString()
  @IsNotEmpty()
  message: string;

  @IsOptional()
  @IsUUID()
  conversationId?: string;
}

export class ChatResponseDto {
  conversationId: string;
  messages: Message[];
}

export class ConversationHistoryDto {
  id: string;
  startedAt: Date;
  finishedAt: Date;
  messageCount: number;
  lastMessage: string;
}
```

**📋 Responsabilidade dos DTOs:**
- **SendMessageDto**: Validação de entrada para envio de mensagens
- **ChatResponseDto**: Padronização da resposta da API
- **ConversationHistoryDto**: Estrutura otimizada para listagem

**📋 Validações Implementadas:**
- **@IsString()**: Garante tipo string
- **@IsNotEmpty()**: Previne mensagens vazias
- **@IsUUID()**: Valida formato de UUID
- **@IsOptional()**: Campo opcional para novas conversas

**❓ Possíveis Questionamentos:**
- **P: Por que usar DTOs ao invés das entidades diretamente?**
  - R: DTOs separam API contract da estrutura de dados, permitindo evolução independente
- **P: Por que class-validator ao invés de Joi ou Yup?**
  - R: Integração nativa com NestJS através de decorators e melhor TypeScript support
- **P: Como tratar erros de validação?**
  - R: NestJS automaticamente retorna 400 Bad Request com detalhes dos erros
- **P: Por que separar Response e Request DTOs?**
  - R: Clareza no contrato da API e flexibilidade para adicionar campos internos

## 6. Configurando o Módulo Principal

### 6.1 Atualizar app.module.ts
```typescript
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ChatModule } from './chat/chat.module';
import { Conversation } from './entities/conversation.entity';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DATABASE_HOST,
      port: parseInt(process.env.DATABASE_PORT),
      username: process.env.DATABASE_USERNAME,
      password: process.env.DATABASE_PASSWORD,
      database: process.env.DATABASE_NAME,
      entities: [Conversation],
      synchronize: true, // Apenas para desenvolvimento
    }),
    ChatModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
```

**📋 Responsabilidade do AppModule:**
- **Configuração Global**: Centraliza configurações da aplicação
- **Injeção de Dependências**: Configura provedores globais
- **Módulos**: Registra todos os módulos da aplicação
- **TypeORM**: Estabelece conexão com banco de dados

**📋 Configurações Críticas:**
- **ConfigModule.forRoot({ isGlobal: true })**: Torna variáveis de ambiente globais
- **synchronize: true**: Apenas para desenvolvimento - cria tabelas automaticamente
- **entities**: Array com todas as entidades da aplicação

**❓ Possíveis Questionamentos:**
- **P: Por que synchronize: true é perigoso em produção?**
  - R: Pode dropar/alterar tabelas automaticamente; usar migrations em produção
- **P: Como configurar SSL para produção?**
  - R: Adicionar ssl: true na configuração TypeORM
- **P: Como usar migrations ao invés de synchronize?**
  - R: npx typeorm migration:generate e migration:run
- **P: Por que não usar Mongoose se temos dados JSON?**
  - R: PostgreSQL JSONB oferece ACID + flexibilidade JSON + queries SQL poderosas

## 7. Criando o Módulo Chat

### 7.1 Criar pasta chat
```bash
mkdir src/chat
```

### 7.2 Criar openai.service.ts
```typescript
import { Injectable } from '@nestjs/common';
import OpenAI from 'openai';

@Injectable()
export class OpenAIService {
  private openai: OpenAI;

  constructor() {
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
  }

  async getChatCompletion(messages: Array<{role: string, content: string}>): Promise<string> {
    const completion = await this.openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: messages as any,
      max_tokens: 1000,
      temperature: 0.7,
    });

    return completion.choices[0].message.content;
  }
}
```

**📋 Responsabilidade do OpenAIService:**
- **Integração Externa**: Interface com API da OpenAI
- **Configuração**: Gerencia chave API e parâmetros
- **Transformação**: Converte formato interno para formato OpenAI
- **Error Handling**: Trata erros de rede e API

**📋 Parâmetros de Configuração:**
- **model**: 'gpt-3.5-turbo' (barato e rápido) ou 'gpt-4' (mais inteligente)
- **max_tokens**: Limite de tokens na resposta (controla custo)
- **temperature**: 0.7 (criatividade moderada, 0=determinístico, 1=criativo)

**❓ Possíveis Questionamentos:**
- **P: Como controlar custos da OpenAI?**
  - R: Usar max_tokens, implementar rate limiting, e monitorar uso via dashboard OpenAI
- **P: Como tratar timeout da OpenAI?**
  - R: Implementar timeout no cliente HTTP e retry com backoff exponencial
- **P: Como fazer streaming de respostas?**
  - R: Usar stream: true na API e implementar Server-Sent Events no frontend
- **P: Como trocar de provider (Anthropic, Cohere)?**
  - R: Criar interface comum e implementar strategy pattern

### 7.3 Criar chat.service.ts
```typescript
import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { v4 as uuidv4 } from 'uuid';
import { Conversation, Message, MessageRole } from '../entities/conversation.entity';
import { OpenAIService } from './openai.service';
import { SendMessageDto, ChatResponseDto, ConversationHistoryDto } from '../dto/chat.dto';

@Injectable()
export class ChatService {
  private readonly logger = new Logger(ChatService.name);

  constructor(
    @InjectRepository(Conversation)
    private conversationRepository: Repository<Conversation>,
    private openaiService: OpenAIService,
  ) {}

  async sendMessage(sendMessageDto: SendMessageDto): Promise<ChatResponseDto> {
    try {
      this.logger.log(`Enviando mensagem: ${sendMessageDto.conversationId ? 'conversa existente' : 'nova conversa'}`);
      
      let conversation: Conversation;

      if (sendMessageDto.conversationId) {
        this.logger.log(`Buscando conversa existente: ${sendMessageDto.conversationId}`);
        
        const foundConversation = await this.conversationRepository.findOne({
          where: { id: sendMessageDto.conversationId, isFinished: false },
        });
        
        if (!foundConversation) {
          this.logger.warn(`Conversa não encontrada ou finalizada: ${sendMessageDto.conversationId}`);
          throw new NotFoundException('Conversa não encontrada');
        }
        
        conversation = foundConversation;
        this.logger.log(`Conversa encontrada com ${conversation.messages.length} mensagens`);
      } else {
        this.logger.log('Criando nova conversa');
        conversation = this.conversationRepository.create({
          messages: [],
          isFinished: false,
        });
      }

      const userMessage: Message = {
        id: uuidv4(),
        role: MessageRole.USER,
        content: sendMessageDto.message,
        timestamp: new Date(),
      };

      conversation.messages.push(userMessage);
      this.logger.log('Mensagem do usuário adicionada');

      const messagesForOpenAI = conversation.messages.map(msg => ({
        role: msg.role,
        content: msg.content,
      }));

      this.logger.log(`Enviando ${messagesForOpenAI.length} mensagens para OpenAI`);
      const aiResponse = await this.openaiService.getChatCompletion(messagesForOpenAI);
      this.logger.log('Resposta recebida da OpenAI');

      const assistantMessage: Message = {
        id: uuidv4(),
        role: MessageRole.ASSISTANT,
        content: aiResponse,
        timestamp: new Date(),
      };

      conversation.messages.push(assistantMessage);

      this.logger.log('Salvando conversa no banco de dados');
      await this.conversationRepository.save(conversation);
      
      this.logger.log(`Conversa salva com sucesso. ID: ${conversation.id}`);

      return {
        conversationId: conversation.id,
        messages: conversation.messages,
      };
    } catch (error) {
      this.logger.error('Erro ao enviar mensagem', error.stack);
      throw error;
    }
  }

  async getConversation(id: string): Promise<ChatResponseDto> {
    try {
      this.logger.log(`Buscando conversa: ${id}`);
      
      const conversation = await this.conversationRepository.findOne({
        where: { id },
      });

      if (!conversation) {
        this.logger.warn(`Conversa não encontrada: ${id}`);
        throw new NotFoundException('Conversa não encontrada');
      }

      this.logger.log(`Conversa encontrada com ${conversation.messages.length} mensagens`);

      return {
        conversationId: conversation.id,
        messages: conversation.messages,
      };
    } catch (error) {
      this.logger.error(`Erro ao buscar conversa ${id}`, error.stack);
      throw error;
    }
  }

  async finishConversation(id: string): Promise<void> {
    try {
      this.logger.log(`Finalizando conversa: ${id}`);
      
      const conversation = await this.conversationRepository.findOne({
        where: { id, isFinished: false },
      });

      if (!conversation) {
        this.logger.warn(`Conversa não encontrada ou já finalizada: ${id}`);
        throw new NotFoundException('Conversa não encontrada ou já finalizada');
      }

      conversation.isFinished = true;
      conversation.finishedAt = new Date();
      
      await this.conversationRepository.save(conversation);
      this.logger.log(`Conversa finalizada com sucesso: ${id}`);
    } catch (error) {
      this.logger.error(`Erro ao finalizar conversa ${id}`, error.stack);
      throw error;
    }
  }

  async getConversationHistory(): Promise<ConversationHistoryDto[]> {
    try {
      this.logger.log('Buscando histórico de conversas');
      
      const conversations = await this.conversationRepository.find({
        where: { isFinished: true },
        order: { finishedAt: 'DESC' },
        take: 20,
      });

      this.logger.log(`Encontradas ${conversations.length} conversas finalizadas`);

      return conversations.map(conv => ({
        id: conv.id,
        startedAt: conv.startedAt,
        finishedAt: conv.finishedAt,
        messageCount: conv.messages.length,
        lastMessage: conv.messages[conv.messages.length - 1]?.content || '',
      }));
    } catch (error) {
      this.logger.error('Erro ao buscar histórico de conversas', error.stack);
      throw error;
    }
  }
}
```

**📋 Responsabilidade do ChatService:**
- **Lógica de Negócio**: Orquestra o fluxo de conversas
- **Persistência**: Gerencia salvamento e recuperação de dados
- **Integração**: Coordena chamadas para OpenAI
- **Validação**: Verifica regras de negócio (conversa ativa, etc.)

**📋 Fluxo de uma Mensagem:**
1. **Validar**: Verifica se conversa existe e está ativa
2. **Adicionar**: Insere mensagem do usuário
3. **Chamar IA**: Envia contexto para OpenAI
4. **Processar**: Adiciona resposta da IA
5. **Persistir**: Salva conversa atualizada
6. **Retornar**: Envia resposta para o cliente

**📋 Logs Implementados:**
- **INFO**: Operações normais e progresso
- **WARN**: Situações atípicas mas não críticas
- **ERROR**: Erros com stack trace completo

**❓ Possíveis Questionamentos:**
- **P: Por que usar Repository Pattern?**
  - R: Abstrai acesso a dados, facilita testes e permite trocar implementação
- **P: Como implementar paginação no histórico?**
  - R: Adicionar parâmetros offset/limit e usar skip/take do TypeORM
- **P: Como implementar busca por texto nas conversas?**
  - R: Usar operadores JSONB do PostgreSQL ou implementar full-text search
- **P: Como garantir que conversas não sejam perdidas?**
  - R: Usar transações do banco e implementar retry logic para falhas temporárias
- **P: Como limitar o tamanho das conversas?**
  - R: Implementar limite de mensagens e usar técnicas de context window management

### 7.4 Criar chat.controller.ts
```typescript
import { Controller, Post, Get, Put, Body, Param, HttpCode, HttpStatus, ParseUUIDPipe, ValidationPipe } from '@nestjs/common';
import { ChatService } from './chat.service';
import { SendMessageDto, ChatResponseDto, ConversationHistoryDto } from '../dto/chat.dto';

@Controller('chat')
export class ChatController {
  constructor(private readonly chatService: ChatService) {}

  @Post()
  @HttpCode(HttpStatus.OK)
  async sendMessage(@Body(ValidationPipe) sendMessageDto: SendMessageDto): Promise<ChatResponseDto> {
    return this.chatService.sendMessage(sendMessageDto);
  }

  @Get('conversations/history')
  async getConversationHistory(): Promise<ConversationHistoryDto[]> {
    return this.chatService.getConversationHistory();
  }

  @Get('conversations/:id')
  async getConversation(@Param('id', ParseUUIDPipe) id: string): Promise<ChatResponseDto> {
    return this.chatService.getConversation(id);
  }

  @Put('conversations/:id/close')
  @HttpCode(HttpStatus.NO_CONTENT)
  async finishConversation(@Param('id', ParseUUIDPipe) id: string): Promise<void> {
    return this.chatService.finishConversation(id);
  }
}
```

**📋 Responsabilidade do ChatController:**
- **Entrada HTTP**: Recebe e valida requisições
- **Roteamento**: Define endpoints da API
- **Validação**: Aplica validadores nos parâmetros
- **Resposta**: Formata retorno para o cliente

**📋 Endpoints Implementados:**
- **POST /chat**: Enviar mensagem (nova ou existente)
- **GET /chat/conversations/history**: Listar conversas finalizadas
- **GET /chat/conversations/:id**: Buscar conversa específica
- **PUT /chat/conversations/:id/close**: Finalizar conversa

**📋 Validadores Aplicados:**
- **ValidationPipe**: Valida DTOs com class-validator
- **ParseUUIDPipe**: Garante formato UUID válido
- **Ordem das rotas**: /history antes de /:id para evitar conflitos

**❓ Possíveis Questionamentos:**
- **P: Por que PUT para fechar conversa ao invés de PATCH?**
  - R: PUT é idempotente e estamos definindo estado final (fechado)
- **P: Por que /history antes de /:id nas rotas?**
  - R: "history" seria interpretado como ID, causando conflito de rota
- **P: Como implementar autenticação?**
  - R: Usar Guards do NestJS com JWT ou sessions
- **P: Como implementar rate limiting?**
  - R: Usar @nestjs/throttler para limitar requests por IP/usuário
- **P: Como versionar a API?**
  - R: Usar prefixo /v1, /v2 ou header Accept-Version

### 7.5 Criar chat.module.ts
```typescript
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ChatController } from './chat.controller';
import { ChatService } from './chat.service';
import { OpenAIService } from './openai.service';
import { Conversation } from '../entities/conversation.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Conversation])],
  controllers: [ChatController],
  providers: [ChatService, OpenAIService],
})
export class ChatModule {}
```

**📋 Responsabilidade do ChatModule:**
- **Modularização**: Isola funcionalidades de chat
- **Injeção de Dependências**: Configura providers locais
- **Importações**: Registra entidades necessárias
- **Exports**: Define o que pode ser usado por outros módulos

**📋 Padrão de Módulo NestJS:**
- **imports**: Outros módulos necessários (TypeOrmModule.forFeature)
- **controllers**: Controllers expostos por este módulo
- **providers**: Services e outros providers internos
- **exports**: (Opcional) providers disponíveis para outros módulos

**❓ Possíveis Questionamentos:**
- **P: Por que não colocar tudo no AppModule?**
  - R: Modularização facilita manutenção, testes e reuso
- **P: Como fazer lazy loading de módulos?**
  - R: Usar Routes com loadChildren para carregamento sob demanda
- **P: Como compartilhar services entre módulos?**
  - R: Exportar no provider e importar o módulo inteiro
- **P: Como organizar módulos em aplicações grandes?**
  - R: Por feature (UserModule, ChatModule) ou por layer (DatabaseModule, ApiModule)

## 8. Configuração Final e Execução

### 8.1 Compilar o projeto
```bash
npm run build
```

### 8.2 Executar em modo desenvolvimento
```bash
npm run start:dev
```

### 8.3 Testar as rotas
```bash
# Criar nova conversa
curl -X POST http://localhost:3000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Olá, como você está?"}'

# Buscar conversa específica
curl http://localhost:3000/chat/conversations/{conversation-id}

# Continuar conversa existente
curl -X POST http://localhost:3000/chat \
  -H "Content-Type: application/json" \
  -d '{"conversationId": "{conversation-id}", "message": "Conte uma piada"}'

# Finalizar conversa
curl -X PUT http://localhost:3000/chat/conversations/{conversation-id}/close

# Buscar histórico
curl http://localhost:3000/chat/conversations/history
```

## 9. Estrutura Final do Projeto

```
src/
├── chat/
│   ├── chat.controller.ts
│   ├── chat.service.ts
│   ├── chat.module.ts
│   └── openai.service.ts
├── dto/
│   └── chat.dto.ts
├── entities/
│   └── conversation.entity.ts
├── app.controller.ts
├── app.service.ts
├── app.module.ts
└── main.ts
```

## 10. Recursos Implementados

### ✅ Funcionalidades
- ✅ Criar nova conversa
- ✅ Continuar conversa existente
- ✅ Finalizar conversa
- ✅ Buscar histórico de conversas
- ✅ Integração com OpenAI API
- ✅ Persistência no PostgreSQL

### ✅ Qualidade do Código
- ✅ Logs detalhados em todas as operações
- ✅ Tratamento de erros com try-catch
- ✅ Validação de entrada com class-validator
- ✅ Validação de UUID nos parâmetros
- ✅ Tipagem completa com TypeScript

### ✅ Arquitetura
- ✅ Separação em módulos
- ✅ Injeção de dependências
- ✅ DTOs para validação
- ✅ Entidades TypeORM
- ✅ Serviços especializados

## 11. Próximos Passos (Opcional)

### Frontend
- React.js ou Next.js
- Interface de chat em tempo real
- Histórico de conversas
- Autenticação de usuários

### Melhorias do Backend
- Autenticação JWT
- Rate limiting
- Paginação no histórico
- Streaming de respostas
- Websockets para tempo real

## 12. Perguntas Técnicas Avançadas para a Live

### 🔧 Performance e Escalabilidade
**P: Como otimizar performance para milhares de usuários simultâneos?**
- R: Implementar connection pooling, cache Redis, horizontal scaling, CDN

**P: Como lidar com rate limiting da OpenAI?**
- R: Implementar queue system (Bull/BullMQ), retry com exponential backoff, circuit breaker

**P: Como reduzir latência das respostas?**
- R: Server-Sent Events para streaming, cache de respostas comuns, edge computing

### 🛡️ Segurança
**P: Como proteger a API Key da OpenAI?**
- R: Variáveis de ambiente, AWS Secrets Manager, rotação automática

**P: Como implementar autenticação robusta?**
- R: JWT + refresh tokens, OAuth2, rate limiting por usuário

**P: Como prevenir ataques de injection?**
- R: Validação rigorosa, sanitização de input, prepared statements

### 🏗️ Arquitetura
**P: Como implementar microservices?**
- R: Separar Chat Service, User Service, AI Service, usar message broker

**P: Como fazer deploy em produção?**
- R: Docker + Kubernetes, CI/CD, health checks, monitoring

**P: Como implementar observabilidade?**
- R: Logs estruturados, metrics (Prometheus), tracing (Jaeger), alertas

### 📊 Monitoramento
**P: Como monitorar custos da OpenAI?**
- R: Métricas de tokens, dashboards, alertas de orçamento, análise de uso

**P: Como detectar conversas anômalas?**
- R: Análise de padrões, detecção de spam, limites de tamanho

### 🔄 Manutenção
**P: Como fazer migrations seguras?**
- R: Backup automático, migrations reversíveis, deploy blue-green

**P: Como fazer rollback em caso de problemas?**
- R: Versionamento de API, feature flags, rollback automático

### 🧪 Testes
**P: Como testar integração com OpenAI?**
- R: Mocks para testes unitários, sandbox da OpenAI para integração

**P: Como testar performance?**
- R: Load testing (Artillery, k6), stress testing, chaos engineering

---

## 📚 Recursos Adicionais

### 📖 Documentação Oficial
- [NestJS Documentation](https://docs.nestjs.com/)
- [TypeORM Documentation](https://typeorm.io/)
- [OpenAI API Reference](https://platform.openai.com/docs/)

### 🎯 Próximos Passos Sugeridos
1. **Frontend React**: Interface de usuário moderna
2. **WebSockets**: Chat em tempo real
3. **Autenticação**: Sistema de usuários
4. **File Upload**: Suporte a imagens/documentos
5. **Plugin System**: Extensibilidade com plugins

### 🔍 Debugging e Troubleshooting
**Problema: "Module not found"**
- Verificar imports e exports dos módulos
- Confirmar se entidades estão registradas

**Problema: "Connection refused" PostgreSQL**
- Verificar se Docker está rodando
- Checar variáveis de ambiente

**Problema: "401 Unauthorized" OpenAI**
- Verificar API Key no .env
- Confirmar créditos na conta OpenAI

---

**Desenvolvido com ❤️ usando NestJS, TypeORM e OpenAI API**

**🎯 Este documento serve como guia completo para recriar o ChatGPT do zero, com explicações detalhadas de cada decisão técnica e antecipação de questionamentos comuns durante desenvolvimento ao vivo!**